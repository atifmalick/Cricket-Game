			  CRICKET TRIVIA  
			    Version 3.0
		    Copyright (C) May 2003 BP.Inc
			 All Rights Reserved
				
			       READ ME
_______________________________________________________________________

  THIS SOFTWARE IS PROVIDED "AS IS", WITHOUT ANY GUARANTEE MADE
  AS TO ITS SUITABILITY OR FITNESS FOR ANY PARTICULAR PURPOSE. IF
  YOU CHOOSE TO USE IT, YOU DO SO ENTIRELY AT YOUR OWN RISK. THE
  AUTHOR TAKES NO RESPONSIBILITY FOR ANY DAMAGE THAT MAY DIRECTLY
  OR INDIRECTLY BE CAUSED THROUGH ITS USE OR MISUSE. IF YOU DO
  NOT OR CANNOT ACCEPT THESE TERMS FOR WHATEVER REASON, DO NOT
  USE THIS SOFTWARE.
_______________________________________________________________________


Contents

   * Introduction
   * To Run
   * Features
   * System Requirements
   


Introduction
Thank you for playing CRICKET TRIVIA version 3.0. CRICKET TRIVIA is a game that test a player's knowledge of internatinal cricket statistics. The game is very simple to play. The question is displayed on the screen and the player is required to answer the it by choosing either A,B,C,D. The player has to answer 40 questions. The questions are based on statistics from both test and one day international cricket. 

To Run
Open TriviaMultiServer.java and execute then run TrivaiClient.java. Provide the Server's Name at the DOS prompt and enjoy the game. 


Features
CRICKET TRIVIA 3.0 is very easy to play. The player can exit the game at any time. The game allows the  player to select a skill level at the beginning of a new game. It also has a simple menu bar that allows the player to change options, exit the game or as was mentioned before, to start a new game at the conclusion of a session etc. It also provdies adequate help for new users of the game.

System Requirements
The Java Virtual Machine (JVM).                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                             